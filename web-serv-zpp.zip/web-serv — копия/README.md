## Лабораторная работа "Веб-сервис"

Backend: Node.js + Express + Mongoose (MongoDB)

### Как Запустить

1. cd backend && yarn && yarn start

2. Other terminal: cd frontend && yarn && sh fix.sh && yarn start
